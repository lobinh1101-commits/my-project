# ERD quản lý đơn đặt hàng

## Tệp trong thư mục
- `ERD_QuanLyDonDatHang.svg`: sơ đồ ERD dạng ảnh vector, có thể mở bằng trình duyệt.
- `ERD_QuanLyDonDatHang.mmd`: mã Mermaid ERD để chỉnh sửa hoặc dựng lại sơ đồ.
- `schema.sql`: lược đồ MySQL mẫu được chuẩn hóa.

## Mô hình
- `DON_VI_KHACH` lưu thông tin đơn vị giao dịch; dùng chung cho bên đặt và bên nhận.
- `HANG` lưu danh mục hàng dùng chung giữa đơn đặt và phiếu giao.
- `CHI_TIET_DON_HANG` giải quyết quan hệ nhiều-nhiều giữa đơn đặt hàng và hàng.
- `CHI_TIET_GIAO_HANG` giải quyết quan hệ nhiều-nhiều giữa phiếu giao hàng và hàng.
- Phiếu giao hàng tham chiếu đơn đặt hàng bằng `SoDH` (cho phép NULL nếu có phiếu giao không gắn trực tiếp với đơn đặt trong quy trình thực tế).
- `ThanhTien` không lưu riêng vì có thể tính bằng `SoLuongGiao * DonGia`, tránh dữ liệu không nhất quán.

## Ghi chú
Đây là mô hình đề xuất đã chuẩn hóa để nộp bài ERD. Nếu giảng viên yêu cầu bám sát chính xác hình mẫu trong tài liệu, có thể cần chỉnh cách thể hiện quan hệ/thuộc tính theo ký hiệu của bài học.
